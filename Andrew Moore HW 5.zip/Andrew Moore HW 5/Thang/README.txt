open one terminal window in the Engine directory
and then enter "make" then "./main" to run the engine server
YOU WILL HAVE TO CTRL-C TO TERMINATE THE ENGINE

open however many more terminal windows and have them all go into GameClient directory
and then enter "make" then "./main" to run the game clients

Use the arrow keys to move and jump
The Escape key is to pause the game (for all clients) and the "P" key is to cycle through the different speeds

Pressing the Escape key and the "P" key at the same time gives the client's character a random fill color


Dying takes 3 seconds to respawn and there are two spawn points, one right next to the left wall and one after the first pit
must die to the right of the spawn point to go there

----------------------------------------------------------------------
grass texture - https://www.textures4photoshop.com/tex/nature-grass-and-foliage/grass-texture-seamless-for-free.aspx