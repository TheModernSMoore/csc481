#pragma once

enum EventType {
    USER_INPUT,
    CHARACTER_COLLISION,
    CHARACTER_DEATH,
    CHARACTER_SPAWN,
    PAUSE,
    CYCLE_SPEED,
    COLOR
};