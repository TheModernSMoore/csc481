// 
// A gentle introduction, using the print callback registered in the native
// main() function
//
print('Happy Wednesday everyone!!!!!!!')
