var PAUSE = 4

if (event1.type == PAUSE) {
    localTime.paused = !(localTime.paused)
}