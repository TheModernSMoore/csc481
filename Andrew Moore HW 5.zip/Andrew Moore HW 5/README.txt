The Thang directory is my implementation of scripts and chords in my platformer

The 2Game directory is my 2nd game

both directories have README's for further instructions