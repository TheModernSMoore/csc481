open one terminal window in the Engine directory
and then enter "make" then "./main" to run the engine server
YOU WILL HAVE TO CTRL-C TO TERMINATE THE ENGINE

then have another terminal window to open the GameClient directory
and then enter "make" then "./main" to run the game client

Use the arrow keys to move
Use the "z" key to shoot
The Escape key is to pause the game and the "P" key is to cycle through the different speeds

The game seg faults when you die so I think it's a pretty good lose condition
----------------------------------------------------------------------
grass texture - https://www.textures4photoshop.com/tex/nature-grass-and-foliage/grass-texture-seamless-for-free.aspx