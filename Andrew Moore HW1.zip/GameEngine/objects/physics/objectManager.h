#pragma once
#include <vector>
#include <typeinfo>
#include <string.h>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "physicsAffected.h"
#include "generic.h"

/// declaration of Generic so the manager can use it 
class Generic;
/// declaration of PhysicsAffected so the manager can use it 
class PhysicsAffected;
/// the class that manages the interactions of each object in the game (or at least the current scope) 
class ObjectManager
{   
    private:
        /// the static list of game objects
        static std::vector<Object*> objects;

    public: 

        /// empty constructor as this class is only used for its static list of objects
        /// and the interactions defined below
        ObjectManager();
        // adds a game object to the objects vector
        void addObject(Object *object);
        // removes a game object from the objects vector
        void removeObject(Object *object);
        // gets the objects vector (used in main for updating, could delegate it to here for [insert smart terminology here])
        std::vector<Object*> getObjects();
        //The five below functions just find all of the objects that are touching a certain object
        //Utilizing the isTouching function in Object
        std::vector<Object*> overlapped(Object *object);

        std::vector<Object*> touching(Object *object);

        std::vector<Object*> touchingBelow(Object *object);

        std::vector<Object*> touchingRight(Object *object);

        std::vector<Object*> touchingLeft(Object *object);

        std::vector<Object*> touchingAbove(Object *object);

        //The five below functions just find all of the physicsAffect objects that are touching a certain object
        //Utilizing the isTouching function in Object
        //These don't work, so idk
        std::vector<PhysicsAffected*> overlappedPhysics(Object *object);

        std::vector<PhysicsAffected*> touchingPhysics(Object *object);

        std::vector<PhysicsAffected*> touchingPhysicsBelow(Object *object);

        std::vector<PhysicsAffected*> touchingPhysicsRight(Object *object);

        std::vector<PhysicsAffected*> touchingPhysicsLeft(Object *object);

        std::vector<PhysicsAffected*> touchingPhysicsAbove(Object *object);
};