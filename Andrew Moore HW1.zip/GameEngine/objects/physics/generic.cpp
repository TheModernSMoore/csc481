#include "generic.h"

template<typename Base, typename T>
inline bool instanceof(const T *ptr) {
   return dynamic_cast<const Base*>(ptr) != nullptr;
}

Generic::Generic() {}

void Generic::move(float offsetX, float offsetY)
{
    Shape::move(offsetX, offsetY);
    ObjectManager objectManager;
    std::vector<Object*> touchers = objectManager.overlapped(this);
    if (touchers.size() > 0)
    {
        Shape::move(-offsetX, -offsetY);
        for (auto & object : touchers)
        {
            if (instanceof<PhysicsAffected>(object)) {
                PhysicsAffected *phy = (PhysicsAffected*) object;
                sf::Vector2f distance = this->distanceBetween(object);
                float x = distance.x != std::numeric_limits<float>::max() ? distance.x : 0;
                float y = distance.y !=std::numeric_limits<float>::max() ? distance.y : 0;
                phy->move(offsetX - x, offsetY - y);   
            }
        }
        Shape::move(offsetX, offsetY);
    }
}