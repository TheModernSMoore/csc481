#include "platform.h"

template<typename Base, typename T>
inline bool instanceof(const T *ptr) {
   return dynamic_cast<const Base*>(ptr) != nullptr;
}

Platform::Platform(sf::Vector2f size)
{
    this->m_size = size;
    sf::Shape::update();
}

void Platform::setSize(sf::Vector2f size)
{
    this->m_size = size;
    sf::Shape::update();
}
        
const sf::Vector2f& Platform::getSize() const
{
    return m_size;
}
        
std::size_t Platform::getPointCount() const
{
    return 4;
}

sf::Vector2f Platform::getPoint(std::size_t index) const
{
    switch (index) {
    case 0:
        return sf::Vector2f(0, 0);
    case 1:
        return sf::Vector2f(m_size.x, 0);
    case 2:
        return sf::Vector2f(m_size.x, m_size.y);
    case 3:
        return sf::Vector2f(0, m_size.y);
    default:
        exit(1);
    }
}

void Platform::setSpeed(float speedx, float speedy)
{
    this->speedx = speedx;
    this->speedy = speedy;
}

void Platform::setRange(float rangex, float rangey)
{
    this->rangex = rangex;
    this->rangey = rangey;
}

void Platform::setPauseTime(float pause)
{
    this->pause = pause;
    this->relTime = pause;
}

void Platform::logic()
{
    if (speedx != 0 || speedy != 0)
    {
        if (relTime < pause) {
            relTime++;
        } else {
            if (relxPos >= rangex || relxPos < 0)
            {
                speedx *= -1;
                relTime = 0;
            }
            if (relyPos >= rangey || relyPos < 0)
            {
                speedy *= -1;
                relTime = 0;
            }
            Generic::move(speedx, speedy);
            ObjectManager objectManager;
            std::vector<Object*> objectsAbove = objectManager.touchingAbove(this);
            for (auto & object : objectsAbove) {
                if (instanceof<PhysicsAffected>(object)) {
                    PhysicsAffected *phy = (PhysicsAffected*) object;
                    phy->move(speedx, speedy);
                }
            }

            relxPos += speedx;
            relyPos += speedy;
        }
    }
    sf::Shape::update();
}