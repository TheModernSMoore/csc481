#include "character.h"

Character::Character(size_t radius ,float speed, float accel, float jump_speed, float down_accel) : PhysicsAffected(down_accel)
{
    this->radius = radius;
    this->speed = speed;
    this->accel = accel;
    this->jump_speed = jump_speed;
    sf::Shape::update();
}

void Character::setSize(size_t radius)
{
    this->radius = radius;
    sf::Shape::update();
}
        
const size_t Character::getSize() const
{
    return radius;
}
        
std::size_t Character::getPointCount() const
{
    return points;
}

void Character::setPointCount(int points)
{
    this->points = points;
    sf::Shape::update();
}

sf::Vector2f Character::getPoint(std::size_t index) const
{
    float angle = 2 * PI * index / points - PI/2;
    float x = radius * cos(angle);
    float y = radius * sin(angle);

    return sf::Vector2f(x, y);
}


void Character::logic()
{
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
        if (curr_speed > 0) {
            curr_speed = 0;
        }
        move(curr_speed <= speed * -1 ? curr_speed : curr_speed -= accel, 0);
    } else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
        if (curr_speed < 0) {
            curr_speed = 0;
        }
        move(curr_speed >= speed ? curr_speed : curr_speed += accel, 0);
    }
    ObjectManager objectManager;
    std::vector<Object*> objectsBelow = objectManager.touchingBelow(this);
    std::vector<Object*> objectsAbove = objectManager.touchingAbove(this);
    if (objectsAbove.size() > 0) {
        vertical_speed = -down_accel;
    } else if (objectsBelow.size() > 0) {
        vertical_speed = -down_accel;
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
            vertical_speed = jump_speed;
        }
    } else if (vertical_speed > term_vel) {
        vertical_speed -= down_accel;
    }
    move(0, term_vel <= vertical_speed ? -vertical_speed : -term_vel);
}