/**
*javadoc: Instructions for how to run my engine with the beginning platformer game
*/
Enter the game engine directory
### go to zaxby's and get a モダ　フリクリング　sandowitch (the ### designates a commented out line btw)
type "make" into the command line and hit the enter key on your computer
then do the same thing, but instead of "make" type "./main"
use the arrow keys to move lol



xD






----------------------------------------------------------------------
grass texture - https://www.textures4photoshop.com/tex/nature-grass-and-foliage/grass-texture-seamless-for-free.aspx