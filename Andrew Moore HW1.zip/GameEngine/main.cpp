#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "objects/platform.h"
#include "objects/character.h"

template<typename Base, typename T>
inline bool instanceof(const T *ptr) {
   return dynamic_cast<const Base*>(ptr) != nullptr;
}


int main(int argc, char const *argv[])
{
    sf::RenderWindow window(sf::VideoMode(800, 600), "SFML Window", sf::Style::Resize);
    // change the position of the window (relatively to the desktop)
    window.setPosition(sf::Vector2i(50, 50));
    window.setFramerateLimit(60);
    ObjectManager objectManager;

    Platform morb(sf::Vector2f(120.f, 25.f));
    morb.setPosition(215.f, 250.f);
    morb.setSpeed(0, 2);
    morb.setRange(0, 200);
    morb.setFillColor(sf::Color(166, 126, 18));

    objectManager.addObject(&morb);

    Platform borb(sf::Vector2f(120.f, 25.f));
    borb.setPosition(375.f, 450.f);
    borb.setSpeed(2, 0);
    borb.setRange(200, 0);
    borb.setFillColor(sf::Color(166, 126, 18));

    objectManager.addObject(&borb);

    Platform ground(sf::Vector2f(800.f, 25.f));
    ground.setPosition(0, 600 - 25);
    sf::Texture texture;
    if (!texture.loadFromFile("img/grass.jpg"))
        return -1;
 
    ground.setTexture(&texture);
    

    objectManager.addObject(&ground);


    Platform wall(sf::Vector2f(25.f, 600-25));
    wall.setPosition(100, 0);

    objectManager.addObject(&wall);

    Platform wall2(sf::Vector2f(25.f, 600-25));
    wall2.setPosition(700, 0);
    
    objectManager.addObject(&wall2);

    Character man(20, 5, 0.5, 10, 0.3);
    man.setPosition(400.f, 50.f);

    objectManager.addObject(&man);

    // run the program as long as the window is open
    while (window.isOpen())
    {

        // check all the window's events that were triggered since the last iteration of the loop
        sf::Event event;
        while (window.pollEvent(event))
        {
            // "close requested" event: we close the window
            if (event.type == sf::Event::Closed)
                window.close();
        }

        // clear the window with black color
        window.clear(sf::Color::Black);

        std::vector<Object*> objects = objectManager.getObjects();

        for (auto & object : objects) {
            object->logic();
        }
        for (auto & object : objects) {
            window.draw(*object);
        }

        // end the current frame
        window.display();
    }
    return 0;
}
